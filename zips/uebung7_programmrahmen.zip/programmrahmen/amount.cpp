
class Amount {
	//ToDo 7.2
	//Implement class Amount 
};

void test() {
	//ToDo 7.2
	//implement tests
}

int main() {
	test();
    return 0;
}